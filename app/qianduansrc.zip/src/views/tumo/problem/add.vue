<template>
    <div class="app-container">
        <el-card>
            <el-form ref="form" :model="form" :rules="rulesForm" label-width="80px">
                <el-form-item label="题目标题" prop="title">
                    <el-input v-model="form.title" placeholder="请输入题目标题" />
                </el-form-item>
                <el-row :gutter="20">
                    <el-col :span="10">
                        <el-form-item label="题目分类" prop="category">
                            <el-select v-model="form.category" value-key="id" placeholder="请选择题目分类" style="width: 100%">
                                <el-option
                                    v-for="item in categoryList"
                                    :key="item.id"
                                    :label="item.name"
                                    :value="item"
                                />
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="14">
                        <el-form-item label="题目标签" prop="tags">
                            <el-select v-model="form.tags" value-key="id" multiple placeholder="请选择题目标签" style="width: 100%">
                                <el-option
                                    v-for="item in tagList"
                                    :key="item.id"
                                    :label="item.name"
                                    :value="item"
                                />
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-form-item label="题目描述" prop="des">
                    <tinymce v-model="form.des" :height="300" />
                </el-form-item>
                <el-form-item label="题目解答" prop="content">
                    <tinymce v-model="form.content" :height="300" />
                </el-form-item>
            </el-form>
            <el-button type="primary" @click="handleSubmit('form')">发布题目</el-button>
        </el-card>
    </div>
</template>

<script>
import { mapGetters } from 'vuex'
import Tinymce from '@/components/Tinymce'
import { getCategoryFilterList } from '@/api/category'
import { getTagFilterList } from '@/api/tag'
import { problemAdd } from '@/api/problem'

export default {
    name: 'Add',
    components: { Tinymce },
    computed: {
        ...mapGetters([
            'qiNiuUploadApi'
        ])
    },
    data() {
        return {
            content: '',
            form: {},
            categoryList: [],
            tagList: [],
            rulesForm: {
                title: [
                    { required: true, message: '请输入题目标题', trigger: 'blur' }
                ],
                des: [
                    { required: true, message: '请输入题目描述', trigger: 'blur' }
                ],
                category: [
                    { required: true, message: '请选择题目分类', trigger: 'change' }
                ],
                tags: [
                    { required: true, message: '请选择题目标签', trigger: 'change' }
                ],
                content: [
                    { required: true, message: '请输入题目解答', trigger: 'blur' }
                ]
            }
        }
    },
    created() {
        this.fetchData()
    },
    methods: {
        fetchData() {
            getCategoryFilterList({}).then(res => {
                this.categoryList = res.data
            })
            getTagFilterList({}).then(res => {
                this.tagList = res.data
            })
        },
        handleSubmit(formName) {
            //this.$refs一个对象 存储所有使用ref属性定义的子组件orDOM元素的引用
            //this.$refs[formName]用于访问指定名称的子组件orDOM元素的引用
            //formName表单名称
            this.$refs[formName].validate((valid) => {
                if (valid) {
                    const formData = {
                        ...this.form
                    }
                    problemAdd(formData).then(res => {
                        if (res.code === 200) {
                            this.$message.success('题目添加成功，即将跳转到题目列表页面')
                            setTimeout(function() {
                                window.location.href = '/tumo/problem'
                            }, 400)
                        } else {
                            this.$message.error(res.msg)
                        }
                    })
                } else {
                    console.log('error submit!!')
                    return false
                }
            })
        }
    }
}
</script>

<style lang="scss" scoped>
</style>
