<template>
    <div>
        <header id="header" class="header bg-white">
            <div class="navbar-container">
                <a href="/" class="navbar-logo">
                    <span>题目管理网站</span>
                </a>
                <div class="navbar-menu">
                    <a href="/login">我的</a>
                </div>
            </div>
        </header>
        <div>
            <router-view />
        </div>

        <footer id="footer" class="footer bg-white">
            <div class="footer-meta">
                <div class="footer-container">
                    <div class="meta-item meta-copyright">
                        <div class="meta-copyright-info">
                            <a href="/" class="info-logo">
                                <span>题目管理网站</span>
                            </a>
                            <div class="info-text">
                                <p>© 2023 华东师范大学 ECNU-SEI</p></div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</template>

<script>
import { getProblemAll} from '@/api/problem'

export default {
    name: 'Layout',
    data() {
        return {
            list: [],
            pageConf: {page: 1, limit: 8, total: 0}
        }
    },
    created() {
        this.fetchData()
    },
    methods: {
        async fetchData() {
            getProblemAll({}, this.pageConf).then( res => {
                if(res.code === 200){
                    console.log("1res:",res,"res.data",res.data)
                    this.list = res.data.rows
                    // this.pageConf.total = res.data.total
                    // this.$forceUpdate()
                }else {
                    this.$message.error(res.msg)
                }
                // this.list = Object.assign(res.data.rows,this.list)
                // // this.list = res.data.rows
                // this.pageConf = Object.assign(res.data.rows,this.pageConf )
                // console.log("this.list       :",this.list)
                // console.log("this.pageConf",this.pageConf)
                // this.isLoading = false
                // setTimeout(()=>{
                //     for(let i=0; i<this.list.length;++i){
                //         let newObj = {
                //             ...this.list[i]
                //         }
                //         this.list[i]=newObj
                //     }
                // },1000)
                console.log(this.list)
            })
        }
    }
}
</script>
