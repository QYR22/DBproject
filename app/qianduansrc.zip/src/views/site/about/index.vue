<template>
  <div>
    <article class="main-content page-page">
      <div class="post-header"><h1 class="post-title" itemprop="name headline"> About </h1>
      </div>
      <div id="post-content" class="post-content">
        <p>加油！</p>
      </div>
    </article>
  </div>

</template>

<script>
export default {
  name: 'Index',
  data() {
    return {
    }
  },
  created() {
  },
  methods: {

  }
}
</script>
<style src="../../../styles/style.min.css"></style>
